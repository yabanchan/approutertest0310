sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("testapprouter20230310.controller.App", {
        onInit() {
        }
      });
    }
  );
  